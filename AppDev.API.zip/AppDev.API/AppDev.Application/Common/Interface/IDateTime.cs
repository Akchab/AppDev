﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;

namespace AppDev.Application.Common.Interface
{
    public interface IDateTime
    {
        DateTime Now { get; set; }
    }
}
